public class State {
  public void mouseDown(int x,int y){}
  public void mouseUp(int x,int y){}
  public void mouseDrag(int x,int y){}
}
